"""Local churn analysis application."""
